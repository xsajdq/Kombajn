// api/auth/login.ts
import loginHandler from '../_handlers/auth/login';

export default loginHandler;
