
import { state } from '../state.ts';
import { t } from '../i18n.ts';
import { can } from '../permissions.ts';
import type { Permission } from '../types.ts';

export function Sidebar() {
    const allNavItems: {id: string, icon: string, text: string, permission?: Permission}[] = [
        { id: 'dashboard', icon: 'dashboard', text: t('sidebar.dashboard'), permission: 'view_dashboard' },
        { id: 'projects', icon: 'folder', text: t('sidebar.projects'), permission: 'view_projects' },
        { id: 'tasks', icon: 'checklist', text: t('sidebar.tasks'), permission: 'view_tasks' },
        { id: 'team-calendar', icon: 'calendar_month', text: t('sidebar.team_calendar'), permission: 'view_team_calendar' },
        { id: 'chat', icon: 'chat', text: t('sidebar.chat'), permission: 'view_chat' },
        { id: 'clients', icon: 'people', text: t('sidebar.clients'), permission: 'view_clients' },
        { id: 'sales', icon: 'monetization_on', text: t('sidebar.sales'), permission: 'view_sales' },
        { id: 'invoices', icon: 'receipt_long', text: t('sidebar.invoices'), permission: 'view_invoices' },
        { id: 'ai-assistant', icon: 'smart_toy', text: t('sidebar.ai_assistant'), permission: 'view_ai_assistant' },
        { id: 'hr', icon: 'groups', text: t('sidebar.hr'), permission: 'view_hr' },
        { id: 'reports', icon: 'assessment', text: t('sidebar.reports'), permission: 'view_reports' },
    ];
    
    const navItems = allNavItems.filter(item => !item.permission || can(item.permission));
    
    const allFooterNavItems: { id: string; icon: string; text: string; permission?: Permission; }[] = [
        { id: 'settings', icon: 'settings', text: t('sidebar.settings'), permission: 'view_settings' },
        { id: 'billing', icon: 'credit_card', text: t('sidebar.billing'), permission: 'manage_billing' }
    ];

    const footerNavItems = allFooterNavItems.filter(item => !item.permission || can(item.permission));


    return `
    <aside class="flex flex-col h-screen w-64 bg-content border-r border-border-color text-sidebar-text">
      <div class="flex items-center p-4 border-b border-border-color">
        <span class="material-icons-sharp text-primary">hub</span>
        <h1 class="text-lg font-bold ml-2 text-text-main">Kombajn</h1>
      </div>
      <nav class="flex-grow p-2" aria-label="Main navigation">
        <ul class="space-y-1">
          ${navItems.map(item => {
            const isActive = state.currentPage === item.id;
            return `
            <li>
              <a href="/${item.id}" class="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${isActive ? 'bg-primary/10 text-primary' : 'hover:bg-background'}" ${isActive ? 'aria-current="page"' : ''}>
                <span class="material-icons-sharp">${item.icon}</span>
                <span class="ml-3">${item.text}</span>
              </a>
            </li>
          `}).join('')}
        </ul>
      </nav>
      <div class="mt-auto p-2 border-t border-border-color">
          <nav aria-label="Footer navigation">
            <ul class="space-y-1">
             ${footerNavItems.map(item => {
                const isActive = state.currentPage === item.id;
                return `
                <li>
                  <a href="/${item.id}" class="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${isActive ? 'bg-primary/10 text-primary' : 'hover:bg-background'}" ${isActive ? 'aria-current="page"' : ''}>
                    <span class="material-icons-sharp">${item.icon}</span>
                    <span class="ml-3">${item.text}</span>
                  </a>
                </li>
             `}).join('')}
            </ul>
          </nav>
      </div>
    </aside>
  `;
}