// api/auth/signup.ts
import signupHandler from '../_handlers/auth/signup';

export default signupHandler;
