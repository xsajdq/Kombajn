import { state } from '../state.ts';
import { renderApp } from '../app-renderer.ts';
import { showModal, closeModal } from './ui.ts';
import type { DashboardWidget, DashboardWidgetType } from '../types.ts';
import { apiFetch, apiPost, apiPut } from '../services/api.ts';

export function toggleEditMode() {
    state.ui.dashboard.isEditing = !state.ui.dashboard.isEditing;
    renderApp();
}

export async function createDefaultWidgets() {
    if (!state.currentUser || !state.activeWorkspaceId) return;

    const defaultWidgets: Omit<DashboardWidget, 'id'>[] = [
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'kpiMetric', config: { metric: 'totalRevenue' }, sortOrder: 0, x: 0, y: 0, w: 1, h: 1 },
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'kpiMetric', config: { metric: 'activeProjects' }, sortOrder: 1, x: 0, y: 0, w: 1, h: 1 },
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'kpiMetric', config: { metric: 'totalClients' }, sortOrder: 2, x: 0, y: 0, w: 1, h: 1 },
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'kpiMetric', config: { metric: 'overdueProjects' }, sortOrder: 3, x: 0, y: 0, w: 1, h: 1 },
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'todaysTasks', config: {}, sortOrder: 4, x: 0, y: 0, w: 1, h: 1 },
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'activityFeed', config: {}, sortOrder: 5, x: 0, y: 0, w: 1, h: 1 },
        { userId: state.currentUser.id, workspaceId: state.activeWorkspaceId, type: 'recentProjects', config: {}, sortOrder: 6, x: 0, y: 0, w: 1, h: 1 },
    ];

    try {
        const savedWidgets = await apiPost('dashboard_widgets', defaultWidgets);
        state.dashboardWidgets.push(...savedWidgets);
        state.dashboardWidgets.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
        renderApp();
    } catch (error) {
        console.error("Failed to create default widgets:", error);
    }
}


export async function addWidget(type: DashboardWidgetType, metricType?: DashboardWidget['config']['metric']) {
    if (!state.currentUser || !state.activeWorkspaceId) return;

    const userWidgets = state.dashboardWidgets.filter(w => 
        w.userId === state.currentUser?.id && w.workspaceId === state.activeWorkspaceId
    );
    
    const maxSortOrder = userWidgets.reduce((max, w) => Math.max(max, w.sortOrder || 0), 0);

    const newWidgetPayload: Omit<DashboardWidget, 'id'> = {
        userId: state.currentUser.id,
        workspaceId: state.activeWorkspaceId,
        type,
        x: 0, 
        y: 0,
        w: 1, 
        h: 1,
        sortOrder: maxSortOrder + 1,
        config: type === 'kpiMetric' ? { metric: metricType } : {}
    };
    
    try {
        const [savedWidget] = await apiPost('dashboard_widgets', newWidgetPayload);
        state.dashboardWidgets.push(savedWidget);
        state.dashboardWidgets.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
        closeModal();
    } catch (error) {
        console.error("Failed to add widget:", error);
        alert("Could not add widget.");
    }
}

export async function removeWidget(widgetId: string) {
    const widgetIndex = state.dashboardWidgets.findIndex(w => w.id === widgetId);
    if (widgetIndex === -1) return;

    const [removedWidget] = state.dashboardWidgets.splice(widgetIndex, 1);
    renderApp();
    try {
        await apiFetch(`/api/data/dashboard_widgets`, {
            method: 'DELETE',
            body: JSON.stringify({ id: widgetId }),
        });
    } catch (error) {
        state.dashboardWidgets.splice(widgetIndex, 0, removedWidget);
        renderApp();
        alert("Could not remove widget.");
    }
}

export function showConfigureWidgetModal(widgetId: string) {
    const widget = state.dashboardWidgets.find(w => w.id === widgetId);
    if (widget) {
        showModal('configureWidget', { widget });
    }
}

export async function handleWidgetConfigSave(widgetId: string) {
    const widget = state.dashboardWidgets.find(w => w.id === widgetId);
    if (!widget) return;

    const originalConfig = { ...widget.config };
    let newConfig = { ...originalConfig };

    const form = document.getElementById('configure-widget-form') as HTMLFormElement;
    if (form && widget.type === 'todaysTasks') {
        const userId = (form.elements.namedItem('userId') as HTMLSelectElement).value;
        newConfig.userId = userId;
    }
    
    widget.config = newConfig;

    try {
        await apiPut('dashboard_widgets', { id: widgetId, config: newConfig });
        closeModal();
    } catch(error) {
        widget.config = originalConfig; // Revert
        alert("Failed to save widget configuration.");
        renderApp();
    }
}

export async function handleGridColumnsChange(newCount: number) {
    const { activeWorkspaceId } = state;
    if (!activeWorkspaceId) return;

    const workspace = state.workspaces.find(w => w.id === activeWorkspaceId);
    if (!workspace) return;

    const originalCount = workspace.dashboardGridColumns;
    workspace.dashboardGridColumns = newCount;
    renderApp(); // Optimistic update

    try {
        await apiPut('workspaces', { id: workspace.id, dashboardGridColumns: newCount });
    } catch (error) {
        console.error("Failed to update grid columns:", error);
        workspace.dashboardGridColumns = originalCount; // Revert
        renderApp();
        alert("Could not save your grid preference.");
    }
}