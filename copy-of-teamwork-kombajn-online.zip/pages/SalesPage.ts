
import { state } from '../state.ts';
import { t } from '../i18n.ts';
import { can } from '../permissions.ts';
import type { Deal } from '../types.ts';
import { fetchSalesData } from '../handlers/deals.ts';
import { formatCurrency } from '../utils.ts';

function renderDealCard(deal: Deal) {
    const client = state.clients.find(c => c.id === deal.clientId);
    const owner = state.users.find(u => u.id === deal.ownerId);

    return `
        <div class="bg-content p-3 rounded-md shadow-sm border border-border-color cursor-pointer deal-card" data-deal-id="${deal.id}" role="button" tabindex="0" draggable="true">
            <p class="font-semibold text-sm mb-2">${deal.name}</p>
            <p class="text-lg font-bold text-primary mb-2">${formatCurrency(deal.value, 'PLN')}</p>
            <div class="flex items-center text-xs text-text-subtle mb-3">
                <span class="material-icons-sharp text-sm mr-1.5">business</span>
                <span>${client?.name || t('misc.no_client')}</span>
            </div>
            <div class="flex justify-between items-center">
                ${owner ? `
                    <div class="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center text-xs font-semibold" title="${t('sales.deal_owner')}: ${owner.name || owner.initials}">${owner.initials}</div>
                ` : `
                    <div class="w-6 h-6 rounded-full bg-background flex items-center justify-center text-text-subtle" title="${t('tasks.unassigned')}">
                         <span class="material-icons-sharp text-base">person_outline</span>
                    </div>
                `}
            </div>
        </div>
    `;
}

function renderKanbanBoard() {
    const deals = state.deals.filter(d => d.workspaceId === state.activeWorkspaceId);
    const stages: Deal['stage'][] = ['lead', 'contacted', 'demo', 'proposal', 'won', 'lost'];
    const dealsByStage: { [key in Deal['stage']]: Deal[] } = {
        lead: [], contacted: [], demo: [], proposal: [], won: [], lost: [],
    };
    deals.forEach(deal => {
        if (dealsByStage[deal.stage]) {
            dealsByStage[deal.stage].push(deal);
        }
    });

    return `
        <div class="flex-1 overflow-x-auto">
            <div class="inline-flex h-full space-x-4 p-1">
                ${stages.map(stage => {
                    const columnDeals = dealsByStage[stage];
                    const totalValue = columnDeals.reduce((sum, deal) => sum + deal.value, 0);

                    return `
                         <div class="flex-shrink-0 w-72 h-full flex flex-col bg-background rounded-lg" data-stage="${stage}">
                            <div class="p-3 font-semibold text-text-main flex justify-between items-center border-b border-border-color">
                                <span>${t(`sales.stage_${stage}`)} <span class="text-sm font-normal text-text-subtle">${columnDeals.length}</span></span>
                            </div>
                            <div class="px-3 py-2 text-sm font-medium text-text-subtle border-b border-border-color">
                                ${formatCurrency(totalValue, 'PLN')}
                            </div>
                            <div class="flex-1 min-h-0 overflow-y-auto p-2 space-y-3">
                                ${columnDeals.length > 0 ? columnDeals.map(renderDealCard).join('') : `<div class="h-full"></div>`}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

export function SalesPage() {
    fetchSalesData();
    const canManage = can('manage_deals');
    const { sales: { isLoading } } = state.ui;

    return `
    <div class="h-full flex flex-col">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-2xl font-bold">${t('sales.title')}</h2>
            <button class="px-3 py-2 text-sm font-medium flex items-center gap-2 rounded-md bg-primary text-white hover:bg-primary-hover disabled:bg-primary/50 disabled:cursor-not-allowed" data-modal-target="addDeal" ${!canManage ? 'disabled' : ''}>
                <span class="material-icons-sharp text-base">add</span> ${t('sales.new_deal')}
            </button>
        </div>
        ${isLoading ? `
            <div class="flex items-center justify-center h-full">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
        ` : renderKanbanBoard()}
    </div>
    `;
}
